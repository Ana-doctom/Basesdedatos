
const conexP = require('../config/dbPostgre');

// función para listar los productos
exports.indexProd = async (req, res) =>{
    try{
        const consulta = `
            SELECT * FROM consultar_productos_con_categorias();
        `;  
        
        const resultado = await conexP.query(consulta);

        // Renderizar la información de los productos para la vista productos
        res.render('post/productos', { productos:resultado.rows});
    }catch(error){
        console.error('Error al obtener todos los productos:', error);
        res.status(500).json({
            message: 'Hubo un error al obtener los productos',
            error: error.message
        });
    }
};

// Funcion para mostrar o ir al formulario de registrar un nuevo producto
exports.create = async (req, res) =>{
    res.render('post/create'); // Lo estamos mandando a el folder de post donde se encuentra la vista de create.ejs
};


exports.store = async (req, res) =>{
    const { nombre, stock, precio, estado, idcategoria } = req.body;
    try{
        const consulta = `
                    SELECT insertar_producto($1, $2, $3, $4, $5)
            `;
        const values = [ nombre,stock, precio, estado, idcategoria];
        
        const resultado = await conexP.query(consulta,values);

        // Renderizar para endpoint lista de productos
        res.redirect('/post');
    }catch(error){
        console.error('Error al obtener todos los productos:', error);
        res.status(500).json({
            message: 'Hubo un error al obtener los productos',
            error: error.message
        });
    }
};

// Función de editar que lo que hace es recibir un parametro del id del producto
// seleccionado para poder cargar la vista del edit y mostrar los datos que contiene
exports.edit = async (req, res) => {
    const { id } = req.params;
    
    try {
        const consulta = `
                        SELECT * FROM consultar_producto($1);
        `;
        
        const resultado = await conexP.query(consulta, [id]);

        if (resultado.rows.length === 0) {
            return res.status(404).json({ message: 'Producto no encontrado' });
        }

        res.render('post/edit', { producto: resultado.rows[0] }); // Si usas EJS o un motor de plantillas

    } catch (error) {
        console.error('Error al obtener el producto:', error);
        res.status(500).json({
            message: 'Hubo un error al obtener el producto.',
            error: error.message
        });
    }
};


// Función del update que registra los cambios efectuados en el edit
exports.update = async (req, res) => {
    const { id } = req.params;
    const { nombre, stock, precio, estado, idcategoria } = req.body;

    try {
        const consulta = `
                        SELECT editar_producto($1, $2, $3, $4, $5, $6);
        `;
        
        const values = [nombre, stock, precio, estado, idcategoria, id];
        
        const resultado = await conexP.query(consulta, values);

        if (resultado.rows.length === 0) {
            return res.status(404).json({ message: 'Producto no encontrado' });
        }

        // Redirigir a la página del producto editado
        //res.redirect(`/post/edit/${id}`);
        res.redirect('/post');

    } catch (error) {
        console.error('Error al actualizar el producto:', error);
        res.status(500).json({
            message: 'Hubo un error al actualizar el producto.',
            error: error.message
        });
    }
};
 
// Eliminar un producto
exports.delete = async (req, res) => {
    const { id } = req.params;

    try {
        const consulta = `
                    SELECT eliminar_producto(1);
        `;
        
        const resultado = await conexP.query(consulta, [id]);

        if (resultado.rows.length === 0) {
            return res.status(404).json({ message: 'Producto no encontrado' });
        }
        res.redirect('/post');

    } catch (error) {
        console.error('Error al eliminar el producto:', error);
        res.status(500).json({
            message: 'Hubo un error al eliminar el producto.',
            error: error.message
        });
    }
};
 
